<?php 
$_['text_day'] = 'Day';
$_['text_hours'] = 'Hrs';
$_['text_days'] = 'Day';
$_['text_min'] 	= 'Min';
$_['text_sec'] 	= 'Sec';
$_['text_sold'] 	= 'Sold';
$_['text_sale_off'] = 'Sale Off';
$_['text_register'] = 'Register';
$_['text_sign_in']  = 'Sign In';
$_['text_myaccount'] = 'My Account';
$_['text_sale'] 	= 'Sale';
$_['text_my_cart'] 		= "Cart";
?>